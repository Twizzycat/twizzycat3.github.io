const discord = () => (window.location.href = "https://discords.com/bio/p/kramos");
const instagram = () => (window.location.href = "https://instagram.com/kramos.oz");
const steam = () => (window.location.href = "https://steamcommunity.com/id/7lh/");
document.body.style.backgroundColor = `#000001`;